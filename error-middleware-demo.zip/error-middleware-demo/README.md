# Error Middleware Demo

This Express.js application demonstrates centralized error handling using custom middleware.

## Learning Objectives
- Understand middleware flow in Express
- Implement custom error-handling middleware
- Throw and catch errors inside routes
- Send structured JSON error responses

## Project Structure
```
error-middleware-demo/
├── server.js          # Main application file
├── package.json       # Project dependencies and scripts
└── README.md         # This documentation
```

## Routes

### Success Route
- **GET /success**
- Returns a successful JSON response
- Response: `{ success: true, message: "...", data: {...} }`

### Error Routes
- **GET /error** - General server error (500)
- **GET /validation-error** - Validation error (400)
- **GET /not-found-error** - Resource not found (404)

### Error Response Format
All errors return structured JSON:
```json
{
  "success": false,
  "message": "Error description",
  "stack": "Error stack trace (development only)"
}
```

## Running the Application

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the server:
   ```bash
   npm start
   ```

3. Server runs on `http://localhost:3001`

## Testing

Use a tool like Postman, Thunder Client, or curl to test the routes:

```bash
# Test success route
curl http://localhost:3001/success

# Test error routes
curl http://localhost:3001/error
curl http://localhost:3001/validation-error
curl http://localhost:3001/not-found-error

# Test 404 for unknown routes
curl http://localhost:3001/unknown-route
```

## Validation Checklist

- ✅ Error-handling middleware function correctly implemented and placed after routes
- ✅ Errors are correctly thrown within route handlers to trigger middleware
- ✅ Middleware correctly catches and processes different types of errors
- ✅ Error responses are structured as JSON with appropriate error codes and messages
- ✅ Application handles errors gracefully without crashing or exposing sensitive information

## Key Features

1. **Centralized Error Handling**: All errors are caught by a single middleware function
2. **Structured Responses**: Consistent JSON format for all error responses
3. **Status Code Handling**: Appropriate HTTP status codes for different error types
4. **Development vs Production**: Stack traces only shown in development mode
5. **404 Handling**: Unknown routes return proper 404 errors