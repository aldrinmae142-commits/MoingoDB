const express = require('express');
const app = express();
const port = 3001;

// Enable JSON parsing
app.use(express.json());

// Demo routes
app.get('/success', (req, res) => {
  res.json({
    success: true,
    message: 'This is a successful response',
    data: { id: 1, name: 'Sample Item' }
  });
});

app.get('/error', (req, res, next) => {
  // Simulate an error
  const error = new Error('Something went wrong!');
  error.statusCode = 500;
  next(error);
});

app.get('/validation-error', (req, res, next) => {
  // Simulate validation error
  const error = new Error('Validation failed: Invalid input');
  error.statusCode = 400;
  next(error);
});

app.get('/not-found-error', (req, res, next) => {
  // Simulate not found error
  const error = new Error('Resource not found');
  error.statusCode = 404;
  next(error);
});

// 404 handler for unknown routes
app.use((req, res, next) => {
  const error = new Error('Route not found');
  error.statusCode = 404;
  next(error);
});

// Custom error-handling middleware
app.use((error, req, res, next) => {
  // Set default error status and message
  const statusCode = error.statusCode || 500;
  const message = error.message || 'Internal Server Error';

  // Log error for debugging (in production, use proper logging)
  console.error(`Error ${statusCode}: ${message}`);

  // Send structured JSON error response
  res.status(statusCode).json({
    success: false,
    message: message,
    // In development, include stack trace; remove in production
    ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
  });
});

app.listen(port, () => {
  console.log(`Error middleware demo server running on http://localhost:${port}`);
});