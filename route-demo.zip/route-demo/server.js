const express = require('express');
const app = express();
const port = 3000;

// Middleware: request logger
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Basic routes
app.get('/', (req, res) => {
  res.send('Welcome to Route Handling!');
});

app.get('/about', (req, res) => {
  res.send('<h1>About Us</h1>');
});

// Dynamic route parameter
app.get('/products/:id', (req, res) => {
  const productId = req.params.id;
  res.send(`Viewing Product ID: ${productId}`);
});

// Query string route
app.get('/search', (req, res) => {
  const term = req.query.q || 'nothing';
  res.send(`Searching for: ${term}`);
});

// JSON response route
app.get('/api/users', (req, res) => {
  const users = [
    { id: 1, name: 'John Doe', email: 'john@example.com' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
  ];
  res.json(users);
});

// 404 catch-all route
app.use((req, res) => {
  res.status(404).send('Page Not Found');
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
